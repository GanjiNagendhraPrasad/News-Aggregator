document.addEventListener('DOMContentLoaded',()=>{
    const allnews=document.getElementById('allnews');
    fetchNews('/all-news');
    allnews.addEventListener('click',()=>{
        fetchNews('/all-news');
    });
    const topheadlines=document.getElementById('topheadlines');
    topheadlines.addEventListener('click',()=>{
        fetchNews('/top-headlines');
    });  
    const countrynews=document.getElementById('countrynews');
    countrynews.addEventListener('click',()=>{
        const countryCode=prompt('Please enter the ISO country code (e.g.,US,IN,GB):');
        if(countryCode){
            fetchNews(`/country/${countryCode}`);
        } 
        else{
            alert('Country code is required to fetch news.');
        }
    }); 
});
function loadnews(news){
    const newsconatiner=document.getElementById('newscontainer');
    newsconatiner.innerHTML='';
    news.forEach(article=>{
         const articleDiv=document.createElement('div');
         articleDiv.className='article';
         const publishedDate=new Date(article.publishedAt).toLocaleDateString();
         articleDiv.innerHTML = `
         <h2>${article.title}</h2>
         <p><strong>Source:</strong>${article.source.name||'Unknown'}</p>
         <p><strong>Author:</strong>${article.author||'Anonymous'}</p>
         <img src="${article.urlToImage||'default-image.jpg'}" alt="News Image" style="max-width: 100%; height: auto;">
         <p><strong>Description:</strong> ${article.description||'No description available'}</p>
         <p><strong>Published At:</strong> ${publishedDate}</p>
         <p><strong>Content:</strong> ${article.content||'No content available'}</p>
         <a href="${article.url}" target="_blank">Read more</a>`;
         newsconatiner.appendChild(articleDiv);
    });
}
function fetchNews(endpoint){
    fetch(endpoint).then(response=>{
        if(!response.ok){
            throw new Error('Network response was not ok');
        }
        return response.json();
    }).then(data=>{
       if(data.data&&data.data.articles){
          loadnews(data.data.articles);
       }
       else{
        console.error('no news data found');
       }
    }).catch(error=>{
        console.error('Error fetching news',error);
    });
}
